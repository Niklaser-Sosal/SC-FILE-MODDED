class ScMapMergeException(Exception):
    """Base Exception"""
    pass
