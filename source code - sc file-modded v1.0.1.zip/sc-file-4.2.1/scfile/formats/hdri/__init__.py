from .decoder import OlCubemapDecoder


__all__ = ("OlCubemapDecoder",)