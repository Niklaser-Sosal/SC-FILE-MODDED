"""sc-file Web UI (local webapp + optional desktop window via pywebview)."""

