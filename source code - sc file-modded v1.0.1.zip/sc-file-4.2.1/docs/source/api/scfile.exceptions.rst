Exceptions
=========================

.. automodule:: scfile.exceptions
  :members:
  :show-inheritance:
  :undoc-members:
