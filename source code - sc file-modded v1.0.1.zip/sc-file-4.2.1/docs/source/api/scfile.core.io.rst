IO
======================

.. automodule:: scfile.core.io
  :no-members:
  :show-inheritance:

Base
--------------------------

.. automodule:: scfile.core.io.base
  :members:
  :show-inheritance:
  :undoc-members:

Streams
-----------------------------

.. automodule:: scfile.core.io.streams
  :members:
  :show-inheritance:
  :undoc-members:
