Context
===========================

.. automodule:: scfile.core.context
  :no-members:
  :show-inheritance:

Options
----------------------------------

.. automodule:: scfile.core.context.options
  :members:
  :show-inheritance:
  :undoc-members:

Content
----------------------------------

.. automodule:: scfile.core.context.content
  :members:
  :show-inheritance:
  :undoc-members:
