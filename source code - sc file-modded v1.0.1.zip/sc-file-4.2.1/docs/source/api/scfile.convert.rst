Convert
======================

.. automodule:: scfile.convert
  :no-members:
  :show-inheritance:

Detect
--------------------------

.. automodule:: scfile.convert.detect
  :members:
  :show-inheritance:
  :undoc-members:

Formats
-----------------------------

.. automodule:: scfile.convert.formats
  :members:
  :show-inheritance:
  :undoc-members:

Legacy
----------------------------

.. automodule:: scfile.convert.legacy
  :members:
  :show-inheritance:
  :undoc-members:

Base
--------------------------

.. automodule:: scfile.convert.base
  :members:
  :show-inheritance:
  :undoc-members:

Factory
-----------------------------

.. automodule:: scfile.convert.factory
  :members:
  :show-inheritance:
  :undoc-members: