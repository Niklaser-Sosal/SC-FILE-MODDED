CLI
==================

.. automodule:: scfile.cli
  :members:
  :show-inheritance:
  :undoc-members:

Utils
-----------------------

.. automodule:: scfile.cli.utils
  :members:
  :show-inheritance:
  :undoc-members:
